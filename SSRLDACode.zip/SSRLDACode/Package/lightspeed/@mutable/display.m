function display(mut)

display(mut.obj)
