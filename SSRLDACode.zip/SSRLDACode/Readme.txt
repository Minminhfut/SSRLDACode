SSRLDA:single domain to single domain 
parameter: default
datasets: office
run demo